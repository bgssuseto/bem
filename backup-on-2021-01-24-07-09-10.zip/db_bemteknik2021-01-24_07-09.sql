#
# TABLE STRUCTURE FOR: anggota
#

DROP TABLE IF EXISTS `anggota`;

CREATE TABLE `anggota` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) NOT NULL,
  `prodi` varchar(20) NOT NULL,
  `departemen` varchar(50) NOT NULL,
  `jabatan` varchar(50) NOT NULL,
  `gambar` varchar(100) NOT NULL,
  `fb` varchar(100) NOT NULL,
  `tw` varchar(100) NOT NULL,
  `linkedin` varchar(100) NOT NULL,
  `instagram` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=latin1;

INSERT INTO `anggota` (`id`, `nama`, `prodi`, `departemen`, `jabatan`, `gambar`, `fb`, `tw`, `linkedin`, `instagram`) VALUES (23, 'Muhammad Habibi', 'Teknik Informatika', '', 'PORA', 'assets/img/team/habibi.jpg', '#', '#', '#', '#');
INSERT INTO `anggota` (`id`, `nama`, `prodi`, `departemen`, `jabatan`, `gambar`, `fb`, `tw`, `linkedin`, `instagram`) VALUES (24, 'Wahyu Akbar Rizki', 'Teknik Informatika', '', 'PORA', 'assets/img/team/default.jpg', '#', '#', '#', '#');
INSERT INTO `anggota` (`id`, `nama`, `prodi`, `departemen`, `jabatan`, `gambar`, `fb`, `tw`, `linkedin`, `instagram`) VALUES (25, 'Laelatul Fitria', 'Teknik Industri', '', 'PORA', 'assets/img/team/lala.jpg', '#', '#', '#', '#');
INSERT INTO `anggota` (`id`, `nama`, `prodi`, `departemen`, `jabatan`, `gambar`, `fb`, `tw`, `linkedin`, `instagram`) VALUES (26, 'Ricky Fardiansha', 'Teknik Informatika', '', 'PORA', 'assets/img/team/ricky.jpg', '#', '#', '#', '#');
INSERT INTO `anggota` (`id`, `nama`, `prodi`, `departemen`, `jabatan`, `gambar`, `fb`, `tw`, `linkedin`, `instagram`) VALUES (27, 'Fikie Fauziyah', 'Sistem Informasi', '', 'RISTEK', 'assets/img/team/fikie.jpg', '#', '#', '#', '#');
INSERT INTO `anggota` (`id`, `nama`, `prodi`, `departemen`, `jabatan`, `gambar`, `fb`, `tw`, `linkedin`, `instagram`) VALUES (28, 'Jalu Army Laksono', 'Sistem Informasi', '', 'RISTEK', 'assets/img/team/jalu.jpg', '#', '#', '#', '#');
INSERT INTO `anggota` (`id`, `nama`, `prodi`, `departemen`, `jabatan`, `gambar`, `fb`, `tw`, `linkedin`, `instagram`) VALUES (29, 'Khoiriyatul Jaza\'', 'Teknik Informatika', '', 'RISTEK', 'assets/img/team/jaz.jpg', '#', '#', '#', '#');
INSERT INTO `anggota` (`id`, `nama`, `prodi`, `departemen`, `jabatan`, `gambar`, `fb`, `tw`, `linkedin`, `instagram`) VALUES (30, 'Ana Fathul Jannah', 'Teknik Informatika', '', 'RISTEK', 'assets/img/team/ana.jpg', '#', '#', '#', '#');
INSERT INTO `anggota` (`id`, `nama`, `prodi`, `departemen`, `jabatan`, `gambar`, `fb`, `tw`, `linkedin`, `instagram`) VALUES (31, 'Rifqi Zulhilmi', 'Teknik Elektro', '', 'RISTEK', 'assets/img/team/hilmi.jpg', '#', '#', '#', '#');
INSERT INTO `anggota` (`id`, `nama`, `prodi`, `departemen`, `jabatan`, `gambar`, `fb`, `tw`, `linkedin`, `instagram`) VALUES (32, 'Ivannovic Bachtiar Alif', 'Teknik Informatika', '', 'MEDINFO', 'assets/img/team/ivan.jpg', '#', '#', '#', '#');
INSERT INTO `anggota` (`id`, `nama`, `prodi`, `departemen`, `jabatan`, `gambar`, `fb`, `tw`, `linkedin`, `instagram`) VALUES (33, 'Zainal Arifin', 'Teknik Informatika', '', 'MEDINFO', 'assets/img/team/zaenal.jpg', '#', '#', '#', '#');
INSERT INTO `anggota` (`id`, `nama`, `prodi`, `departemen`, `jabatan`, `gambar`, `fb`, `tw`, `linkedin`, `instagram`) VALUES (34, 'Gilang Adi Sasongko', 'Teknik Informatika', '', 'MEDINFO', 'assets/img/team/gilang.jpg', '#', '#', '#', '#');
INSERT INTO `anggota` (`id`, `nama`, `prodi`, `departemen`, `jabatan`, `gambar`, `fb`, `tw`, `linkedin`, `instagram`) VALUES (35, 'Ira Puspita Sari', 'Sistem Informasi', '', 'MEDINFO', 'assets/img/team/default.jpg', '#', '#', '#', '#');
INSERT INTO `anggota` (`id`, `nama`, `prodi`, `departemen`, `jabatan`, `gambar`, `fb`, `tw`, `linkedin`, `instagram`) VALUES (36, 'Bayu Bagaskara', 'Teknik Informatika', '', 'HUBLU', 'assets/img/team/bayu.jpg', '#', '#', '#', '#');
INSERT INTO `anggota` (`id`, `nama`, `prodi`, `departemen`, `jabatan`, `gambar`, `fb`, `tw`, `linkedin`, `instagram`) VALUES (37, 'Tea Romdlonatunni\'mah', 'Teknik Industri', '', 'HUBLU', 'assets/img/team/tea.jpg', '#', '#', '#', '#');
INSERT INTO `anggota` (`id`, `nama`, `prodi`, `departemen`, `jabatan`, `gambar`, `fb`, `tw`, `linkedin`, `instagram`) VALUES (38, 'Farich Al Azami', 'Teknik Informatika', '', 'Ka. Dep. Kesejahteraan Mahasiswa', 'assets/img/team/fiza.jpg', '#', '#', '#', '#');
INSERT INTO `anggota` (`id`, `nama`, `prodi`, `departemen`, `jabatan`, `gambar`, `fb`, `tw`, `linkedin`, `instagram`) VALUES (39, 'bagus', 'Teknik Informatika', 'sadsad', 'sadjsad', '119431997_184179229978594_4038730361309086751_o.jpg', '', '', '', '');


#
# TABLE STRUCTURE FOR: inbox
#

DROP TABLE IF EXISTS `inbox`;

CREATE TABLE `inbox` (
  `id_pesan` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(50) NOT NULL,
  `email` varchar(20) NOT NULL,
  `subjek` varchar(40) NOT NULL,
  `pesan` text NOT NULL,
  PRIMARY KEY (`id_pesan`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;

#
# TABLE STRUCTURE FOR: pengumuman
#

DROP TABLE IF EXISTS `pengumuman`;

CREATE TABLE `pengumuman` (
  `id_pengumuman` int(11) NOT NULL AUTO_INCREMENT,
  `judul` varchar(100) NOT NULL,
  `isi` varchar(255) NOT NULL,
  `gambar` varchar(255) NOT NULL,
  `dibuat` datetime NOT NULL,
  `diedit` datetime DEFAULT NULL,
  `author` varchar(10) NOT NULL,
  PRIMARY KEY (`id_pengumuman`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: wkwk
#

DROP TABLE IF EXISTS `wkwk`;

CREATE TABLE `wkwk` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` varchar(10) NOT NULL,
  `pass` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `wkwk` (`id`, `user`, `pass`) VALUES (1, 'bagus', '$2y$10$7DN542cxYnR6JHhjw.tLtOAWa03lA/lfZUXF6GS9jeBtdmwuHco1S');


